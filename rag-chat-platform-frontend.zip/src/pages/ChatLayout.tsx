import { useEffect, useMemo, useRef, useState } from "react";
import TracePanel from "../features/trace/components/TracePanel";
import { useChatStore } from "../features/chat/store/chatStore";
import { useChatActions } from "../features/chat/useChatActions";
import type { Message } from "../features/chat/types";

export default function ChatLayout() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 60_000);
    return () => clearInterval(t);
  }, []);

  function formatNow(d: Date) {
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const dd = String(d.getDate()).padStart(2, "0");
    const hh = String(d.getHours()).padStart(2, "0");
    const min = String(d.getMinutes()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd} ${hh}:${min}`;
  }

  // ✅ Store only
  const conversations = useChatStore((s) => s.conversations);
  const activeId = useChatStore((s) => s.activeId);
  const setActive = useChatStore((s) => s.setActive);
  const newChat = useChatStore((s) => s.newChat);

  // ✅ persist 복원 시 activeId가 null인 경우가 있음 → 첫 대화로 자동 선택
  useEffect(() => {
    if (!activeId && conversations.length > 0) {
      setActive(conversations[0].id);
    }
  }, [activeId, conversations, setActive]);

  const activeConversationId = activeId ?? (conversations[0]?.id ?? null);

  const activeConversation = useMemo(() => {
    if (!activeConversationId) return null;
    return conversations.find((c) => c.id === activeConversationId) ?? null;
  }, [conversations, activeConversationId]);

  const activeTitle = activeConversation?.title ?? "New Chat";
  const messages = activeConversation?.messages ?? [];

  const { send } = useChatActions(); // stop 안 쓰면 꺼내지 마세요(경고 방지)

  async function onSend(text: string) {
    const trimmed = text.trim();
    if (!trimmed) return;

    let cid = activeConversationId;
    if (!cid) {
      useChatStore.getState().newChat();
      cid = useChatStore.getState().activeId;
      if (!cid) return;
    }

    await send(cid, trimmed);
  }

  function onNewChat() {
    newChat();
  }

  return (
    <div className="h-screen overflow-hidden grid grid-cols-[320px_1fr_360px] bg-white text-slate-900">
      {/* Sidebar */}
      <aside className="min-h-0 border-r border-slate-200 bg-slate-50 p-4 flex flex-col gap-3">
        <div className="pb-1">
          <div className="font-bold">rag-chat-platform</div>
          <div className="text-xs text-slate-400">{formatNow(now)}</div>
        </div>

        <button
          onClick={onNewChat}
          className="px-3 py-2 rounded-xl border border-slate-300 bg-white hover:bg-slate-100 text-slate-900 font-semibold"
        >
          + New Chat
        </button>

        <div className="text-xs text-slate-400 mt-2">Conversations</div>

        <nav className="flex-1 flex flex-col gap-2 overflow-auto pr-1">
          {conversations.map((c) => {
            const active = c.id === activeConversationId;
            return (
              <button
                key={c.id}
                onClick={() => setActive(c.id)}
                className={[
                  "p-3 rounded-xl border text-left transition",
                  active ? "border-slate-400 bg-white" : "border-slate-200 hover:bg-slate-100",
                ].join(" ")}
                title={c.title}
              >
                <div className="text-sm font-semibold truncate">{c.title}</div>
                <div className="text-[11px] text-slate-400 mt-1">{c.updatedAt}</div>
              </button>
            );
          })}
        </nav>

        <div className="mt-auto flex items-center justify-between gap-3">
          <div className="text-xs text-slate-400">Guest</div>
          <button
            className="text-xs text-indigo-300 hover:text-indigo-200"
            onClick={() => alert("로그인 연결 전")}
          >
            Login (later)
          </button>
        </div>
      </aside>

      {/* Main */}
      <main className="min-h-0 overflow-hidden grid grid-rows-[56px_1fr_auto] bg-white">
        <header className="h-14 px-4 flex items-center justify-between bg-white">
          <div className="text-sm font-bold">{activeTitle}</div>
          <button
            className="text-xs px-3 py-2 rounded-xl border border-slate-300 bg-white hover:bg-slate-100 text-slate-700"
            onClick={() => alert("설정은 나중에")}
          >
            Settings (later)
          </button>
        </header>

        <MessageList messages={messages} />

        <MessageInput onSend={onSend} />
      </main>

      {/* Trace */}
      <TracePanel conversationId={activeConversationId} />
    </div>
  );
}

// ChatPage.tsx 하단의 MessageList 함수 수정

function MessageList({ messages }: { messages: Message[] }) {
  const bottomRef = useRef<HTMLDivElement | null>(null);

  // [수정] messages.length -> messages
  // 메시지 내용이 변할 때마다(스트리밍 중) 스크롤이 내려갑니다.
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  return (
    <div className="min-h-0 p-4 overflow-auto">
      {/* ... (중간 렌더링 코드는 기존과 동일) ... */}
      
      {messages.length === 0 ? (
        <div className="max-w-xl border border-dashed border-slate-300 rounded-2xl p-5 text-slate-700">
          <div className="font-bold mb-1">대화를 시작하세요</div>
          <div className="text-sm text-slate-500">메시지를 입력하면 스트리밍 응답이 표시됩니다.</div>
        </div>
      ) : (
        messages.map((m) => (
          <div
            key={m.id}
            className={`flex mb-2 ${m.role === "user" ? "justify-end" : "justify-start"}`}
          >
            <div
              className={`max-w-2xl rounded-2xl px-3 py-2 border ${
                m.role === "user"
                  ? "bg-white border-slate-200 text-slate-900"
                  : "bg-slate-100 border-slate-300 text-slate-900"
              }`}
            >
              <div className="text-sm whitespace-pre-wrap leading-relaxed">
                {m.content}
                {/* 스트리밍 중일 때 커서 깜빡임 효과 */}
                {m.status === "streaming" ? <span className="animate-pulse">▍</span> : null}
              </div>
              <div className="text-[11px] text-slate-400 mt-1">
                {m.createdAt}
                {m.status === "error" ? " · error" : ""}
              </div>
            </div>
          </div>
        ))
      )}
      {/* 스크롤 타겟 */}
      <div ref={bottomRef} />
    </div>
  );
}

function MessageInput({ onSend }: { onSend: (text: string) => void | Promise<void> }) {
  const [text, setText] = useState("");

  async function submit() {
    const t = text;
    setText("");
    await onSend(t);
  }

  return (
    <div className="p-3 flex gap-2 items-end bg-white">
      <textarea
        className="flex-1 resize-none rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm outline-none focus:border-slate-500"
        rows={2}
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="메시지를 입력하세요…"
        onKeyDown={(e) => {
          if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            void submit();
          }
        }}
      />
      <button
        onClick={() => void submit()}
        className="px-4 py-2 rounded-xl border border-slate-300 bg-slate-900 text-white hover:bg-slate-800 font-semibold text-sm"
      >
        Send
      </button>
    </div>
  );
}
