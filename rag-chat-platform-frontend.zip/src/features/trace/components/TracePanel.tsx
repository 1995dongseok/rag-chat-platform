/* eslint-disable @typescript-eslint/no-explicit-any */
import { useEffect, useMemo, useState, useRef } from "react";
import { useTraceStore, type TraceEvent } from "../store/traceStore";

type Props = {
  conversationId: string | null;
};

const EMPTY_EVENTS: TraceEvent[] = [];

export default function TracePanel({ conversationId }: Props) {
  const [round, setRound] = useState<1 | 2>(1);
  const hasAutoSwitched = useRef<string | null>(null);

  const events = useTraceStore((s) => {
    if (!conversationId) return EMPTY_EVENTS;
    return s.byConversation[conversationId] ?? EMPTY_EVENTS;
  });

  // 1. 대화방이 바뀌거나(ID 변경), 데이터가 비워지면(Clear 실행 시) 1번 탭으로 리셋
  useEffect(() => {
    setRound(1);
    hasAutoSwitched.current = null;
  }, [conversationId, events.length === 0]); 

  // 2. 자동 전환 로직
  useEffect(() => {
    const hasRound2Data = events.some((e) => e.round === 2);
    if (round === 1 && hasRound2Data && hasAutoSwitched.current !== conversationId) {
      setRound(2);
      hasAutoSwitched.current = conversationId;
    }
  }, [events, round, conversationId]);

  const { retrieval, rerank, verification } = useMemo(() => {
    const filtered = events.filter((e) => e.round === round);
    return {
      retrieval: filtered.filter((e) => e.type === "retrieval"),
      rerank: filtered.filter((e) => e.type === "rerank"),
      verification: filtered
        .filter((e) => e.type === "verification")
        .at(-1) as Extract<TraceEvent, { type: "verification" }> | undefined,
    };
  }, [events, round]);

  // [수정] 만능 PASS 판독기 (이 부분을 복사해서 붙여넣으세요)
  const isPass = useMemo(() => {
    if (!verification) return false;
    
    // 1. 안전하게 payload 접근
    const p = verification.payload as any;
    if (!p) return false;

    // Case A: 정석대로 들어온 경우 ({ pass: true })
    if (p.pass === true || String(p.pass) === "true") return true;

    // Case B: 한 번 더 감싸져서 들어온 경우 ({ payload: { pass: true } })
    // useChatActions 등에서 데이터를 넣을 때 중첩되는 경우가 많음
    if (p.payload && (p.payload.pass === true || String(p.payload.pass) === "true")) return true;

    // Case C: 'is_pass' 같은 다른 키값으로 들어온 경우 (혹시 모를 대비)
    if (p.is_pass === true || String(p.is_pass) === "true") return true;

    return false;
  }, [verification]);

  const renderDocCard = (doc: any, index: number, isRerank: boolean) => {
    const change = doc.metadata?.rank_change ?? 0;
    
    return (
      <div key={index} className="mb-2 p-2 bg-white border border-slate-200 rounded-lg text-xs shadow-sm">
        <div className="flex justify-between items-center mb-1">
          <div className="flex items-center gap-2">
            <span className={`font-bold px-1.5 py-0.5 rounded ${
              isRerank ? "bg-indigo-50 text-indigo-700" : "bg-slate-100 text-slate-600"
            }`}>
              {isRerank ? `Rank ${index + 1}` : `Retr ${index + 1}`}
            </span>
            
            {isRerank && change !== 0 && (
              <span className={`text-[10px] font-bold flex items-center ${
                change > 0 ? "text-emerald-600" : "text-rose-500"
              }`}>
                {change > 0 ? "↑" : "↓"} {Math.abs(change)}
              </span>
            )}
          </div>

          {doc.score && (
            <span className="text-[10px] text-slate-400 font-mono bg-slate-50 px-1 rounded">
              {typeof doc.score === 'number' ? doc.score.toFixed(3) : doc.score}
            </span>
          )}
        </div>
        
        <div className="text-slate-700 line-clamp-2 mb-1 leading-snug">
          {doc.content || (typeof doc === 'string' ? doc : JSON.stringify(doc))}
        </div>
        {doc.metadata?.url && (
          <div className="text-[9px] text-blue-500 truncate hover:underline cursor-pointer">
            {doc.metadata.url}
          </div>
        )}
      </div>
    );
  };

  return (
    <aside className="min-h-0 border-l border-slate-200 bg-slate-50 p-3 overflow-auto w-80">
      <div className="flex gap-2 mb-4">
        {[1, 2].map((r) => (
          <button
            key={r}
            className={`flex-1 py-1.5 text-xs font-semibold rounded-md border transition-all ${
              round === r ? "bg-white border-slate-300 shadow-sm text-indigo-600" : "bg-slate-100 border-transparent text-slate-500"
            }`}
            onClick={() => setRound(r as 1 | 2)}
          >
            Round {r}
          </button>
        ))}
      </div>

      <section className="mb-6">
        <div className="flex items-center gap-2 mb-2">
          <div className="w-1 h-4 bg-slate-300 rounded-full"></div>
          <div className="font-bold text-slate-700 text-sm">Retrieval</div>
          <span className="text-[10px] text-slate-400">({(retrieval.at(-1)?.payload as any[])?.length || 0})</span>
        </div>
        <div className="max-h-60 overflow-y-auto pr-1">
          {retrieval.length === 0 ? (
            <div className="text-xs text-slate-400 italic py-2">— No data</div>
          ) : (
            (retrieval.at(-1)?.payload as any[]).map((doc, i) => renderDocCard(doc, i, false))
          )}
        </div>
      </section>

      <section className="mb-6">
        <div className="flex items-center gap-2 mb-2">
          <div className="w-1 h-4 bg-indigo-400 rounded-full"></div>
          <div className="font-bold text-slate-700 text-sm">Rerank</div>
        </div>
        <div className="max-h-60 overflow-y-auto pr-1">
          {rerank.length === 0 ? (
            <div className="text-xs text-slate-400 italic py-2">— No reranked data</div>
          ) : (
            (rerank.at(-1)?.payload as any[]).map((doc, i) => renderDocCard(doc, i, true))
          )}
        </div>
      </section>

      <section className="border-t border-slate-200 pt-4">
        <div className="flex items-center justify-between mb-3">
          <div className="font-bold text-slate-700 text-sm">Verification</div>
          {verification && (
            <span className={`px-2 py-0.5 rounded text-[10px] font-black tracking-wider ${
              isPass ? "bg-emerald-100 text-emerald-700" : "bg-rose-100 text-rose-700"
            }`}>
              {isPass ? "PASS" : "FAIL"}
            </span>
          )}
        </div>

        {!verification ? (
          <div className="text-xs text-slate-400 italic">— Waiting for evaluation</div>
        ) : (
          <div className="space-y-3">
            {verification.payload.ragas && (
              <div className="grid grid-cols-1 gap-2 bg-white p-2 border border-slate-200 rounded-lg shadow-sm">
                {Object.entries(verification.payload.ragas).map(([key, val]) => (
                  <div key={key}>
                    <div className="flex justify-between text-[9px] uppercase font-bold text-slate-500 mb-0.5">
                      <span>{key.replace(/_/g, ' ')}</span>
                      <span>{Math.round((val as number) * 100)}%</span>
                    </div>
                    <div className="w-full bg-slate-100 h-1 rounded-full overflow-hidden">
                      <div 
                        className="bg-indigo-500 h-full transition-all duration-700" 
                        style={{ width: `${(val as number) * 100}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
            
            {verification.payload.reason && (
              <div className="text-[11px] text-slate-600 bg-white p-2 border-l-2 border-slate-300 rounded-r-md leading-relaxed">
                <span className="font-bold text-slate-400 block mb-0.5 uppercase text-[9px]">Comment</span>
                {verification.payload.reason}
              </div>
            )}
          </div>
        )}
      </section>
    </aside>
  );
}